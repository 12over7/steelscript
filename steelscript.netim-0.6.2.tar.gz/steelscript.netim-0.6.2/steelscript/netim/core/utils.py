# Copyright (c) 2019 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.

"""
This module contains the NetIM class, which is the main interface to
a SteelCentral NetIM. It provides functionality to query devices 
managed by NetIM, attributes of those devices, metrics, and other 
data relavant to NetIM capabilities exposed via the API.
"""


from __future__ import print_function
import sys
import logging

import steelscript.netim.core.netim
from steelscript.netim.core.netim import *

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

try:
    logger = logging.getLogger(__name__)
except Exception as e:
    eprint(e)

'''
    def logr(self, *args, **kwargs):
        if logger.__class__ == logging.Logger:
            return logger(args, kwargs)
        else
            return Null

    def logCritical(self, logEntry):
        if logr:
            return self.logr.critical(logEntry)

    def logError(self, logEntry):
        if logr:
            return self.logr.error(logEntry)

    def logWarning(self, logEntry):
        if logr:
            return self.logr.warning(logEntry)

    def logInfo(self, logEntry):
        if logr:
            return self.logr.info(logEntry)
'''


def json2table_depth1(qrj, cols):
    # parse query result jason and return table
    # columns refer to keys in each item record
    t = []
    if not u'items' in qrj:
        return t
    for d in qrj[u'items']:
        row = []
        for k in cols:
            if k in d:
                row.append(d[k])
            else:
                row.append('')
        t.append(row)
    logger.debug('Returned %s records' % len(t))
    return t

def update_polling_profile_by_group(n, grp2poll):
    # grp2poll format:
    # group ID, Polling profile ID
    for grec in grp2poll:
        devs = n.get_devices_in_group(grec[0])
        for drec in devs:
            n.update_polling_profile(n.get_deviceAccessInfoId(drec[0]), grec[1])

def update_alert_profile_by_group(n, grp2alert):
    # grp2alert: column 0 is groupID, column 1 is alertProfileID
    for alertRec in grp2alert:
        devs = n.get_devices_in_group(alertRec[0])
        for drec in devs:
            print('Processing DeviceID %s  ....' % drec[0])
            devAccId = n.get_deviceAccessInfoId(drec[0])
            print('\tdeviceAccessInfoId: %s' % devAccId)
            if len(devAccId) < 1:
                continue
            resp = n.update_alert_profile(devAccId, alertRec[1] )
            pprint(resp)



