# Copyright (c) 2019 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.

"""
This module contains the NetIM class, which is the main interface to
a SteelCentral NetIM. It provides functionality to query devices 
managed by NetIM, attributes of those devices, metrics, and other 
data relavant to NetIM capabilities exposed via the API.
"""


import json
import base64
import logging
import os
import pandas

from steelscript.common.connection import Connection
from steelscript.common.service import Service
from steelscript.common._fs import SteelScriptDir
from steelscript.netim.core.utils import eprint

try:
    logger = logging.getLogger(__name__)
except Exception as e:
    eprint(e)


class NetIM(Service):
    """ NetIM device instance. """
    #SERVICE_ID = '/api/netim/{version}'
    
    def __init__(self, host, port, auth):
        self.auth = auth
        super(NetIM, self).__init__('NetIM', host, port, auth)
        
        version = 'v1'

        self.base_url = ("https://%s:%s/api/netim/%s/"
                         % (host, port, version))
        # self.base_url = ("http://%s:%s/api/netim/%s/"
        #                 % (host, '9190', version))
        
        self.swagger_url = ("http://%s:%s/api/netim/swagger.json"
                         % (host, port))
        
        self.ss_dir = SteelScriptDir('NetIM', 'files')
        
        self.authenticate(auth)
        
        #self.get_swagger()
        
        
    def check_api_versions(self, api_versions):
        pass

    def authenticate(self, auth):
        # Use HTTP Basic authentication only
        s = base64.b64encode("%s:%s" % (self.auth.username, self.auth.password))
        self.conn.add_headers({'Authorization': 'Basic %s' % s})
        
        logger.info("Authenticated using BASIC")
    
    def get_swagger(self):
        # Download Swagger
        sy = 'swagger.yaml'
        sj = 'swagger.json'
        for swf in (sy, sj):
            fqp = self.ss_dir.basedir + os.sep + swf
            swurl = 'https://%s:%s/api/netim/%s' % (self.host, self.port, swf)
            if os.path.isfile(fqp + '.bk'):
                os.remove(fqp + '.bk')
            if os.path.isfile(fqp):
                os.rename(fqp, fqp + '.bk')
            try:
                content = self._req(u'GET', swurl)
                with open(fqp, "w") as ofo:
                    ofo.write(content)
            except:
                logger.warning("Unable to download %s " % swurl)
    
    def get_devices(self, **a):
        # return json object of all managed devices
        # Requires key=value arguments passed to web function
        fargs = '?'
        for param, value in a.items():
            fargs += "%s=%s&" % (param, value)
        if fargs.__len__() < 3:
            fargs = ''
        return self._get('devices%s' % fargs[:-1])
    
    def get_devices_all(self, **a):
        # default device query returns 1000 items
        # iterates through list to get all devoies
        # a['offset'] = 0
        a['limit'] = 12000
        d = self.get_devices(**a)
        if self._validate_mget(d):
            return d
        return []

    def get_groups(self):
        # return json object of all groups
        return self._get('groups')

    def get_group(self, grpId):
        # return json object of all groups
        return self._get('groups/%s' % grpId)

    def get_group_devices(self, grpId):
        # return json object of all groups
        return self._get('groups/%s/devices' % grpId)

    def get_device_info(self, devId):
        # return json object with device info
        # require device ID
        return self._get('devices/%s' % devId)

    def get_deviceAccessInfoId(self, devId):
        d = self.get_device_info(devId)
        if u'deviceAccessInfoId' in d:
            return d[u'deviceAccessInfoId']
        else:
            return ''

    def get_device_table(self):
        cols = [u'name', u'deviceName', u'id', u'deviceType']
        r = self.get_devices_all()
        return json2table_depth1(r, cols)

    def get_interfaces(self, **a):
        # Returns all of the interfaces in the data model 
        # matching the supplied parameters.
        # Requires key=value arguments passed to web function
        fargs = '?'
        for param, value in a.items():
            fargs += "%s=%s&" % (param, value)
        if fargs.__len__() < 3:
            fargs = ''
        return self._get('interfaces%s' % fargs[:-1])
    
    def get_dev_interfaces(self, devid, **a):
        # return json object with device interface info
        # require device ID
        fargs = '?'
        for param, value in a.items():
            fargs += "%s=%s&" % (param, value)
        if fargs.__len__() < 3:
            fargs = ''
        return self._get('devices/%s/interfaces/%s' % (devid, fargs[:-1]))

    def update_alert_profile(self, devAccId, alertProfileId, **a):
        logger.info('Request to add DeviceAccessId %s to Alert %s' % (devAccId, alertProfileId) )
        a = []
        alert = self.get_alert_profile(alertProfileId)
        if u'deviceAccessInfoIds' in alert:
            a = alert[u'deviceAccessInfoIds']
            if devAccId in a:
                logger.info('DeviceAccessId %s is already using Alert %s  - nothing to do.' % (devAccId, alertProfileId))
                return a
        # a contains a list of device access IDs for alert profile
        a.append(devAccId)
        postdata = json.loads(u'{  deviceAccessInfoIds : [ %s ] }' % devAccId )
        return self._req( u'PATCH', u'alert-profiles/%s' % alertProfileId, postdata)

    def update_polling_profile(self, devAccId, pollingProfileId, **a):
        logger.info('Request for DeviceAccessId %s to use Polling %s' % (devAccId, pollingProfileId) )
        p = self.get_polling_profile(pollingProfileId)
        if u'deviceAccessInfoId' in p:
            if p[u'deviceAccessInfoId'] == pollingProfileId:
                logger.info('DeviceAccessId %s is already using Polling %s  - nothing to do.' % (devAccId, pollingProfileId))
                return pollingProfileId
            else:
                postdata = json.loads(u'{  deviceAccessInfoId : %s  }' % devAccId)
                return self._req( u'PATCH', u'polling-profiles/%s' % pollingProfileId, postdata)

    def get_devintfc_all(self, devid, **a):
        # default device query returns 1000 items
        # iterates through list to get all interfaces
        # a['offset'] = 0
        a['limit'] = 12000
        return self.get_dev_interfaces(devid, **a)

    def get_interface(self, intid):
        # return json object with interface info
        # require interface ID
        return self._get('interfaces/%s' % intid)
    
    def get_sub_interfaces(self, intid):
        # return json object with device interface info
        # require parent interface ID
        return self._get('interfaces/%s/sub-interfaces' % intid)
    
    def get_intfc_custom(self, intid):
        # return json object with custom attribute values of the interface
        # require interface ID
        return self._get('interfaces/%s/custom-attribute-values' % intid)
    
    def get_intfc_aggr(self, intid):
        # return json object with aggregated interfaces for the interface
        # require interface ID
        return self._get('interfaces/%s/agg-interfaces' % intid)

    def get_interface_table(self, devId):
        cols = [u'name', u'ifPreferredName', u'id', u'ifType', u'ifAdminStatus', u'ifOperStatus', u'containers']
        r = self.get_dev_interfaces(devId)
        return json2table_depth1(r, cols)

    def get_intfc_links(self, intid):
        # return json object with all of the links associated with the interface
        # require interface ID
        return self._get('interfaces/%s/links' % intid)
    
    def get_dev_links(self, devid):
        # return json object with link info
        # require device ID
        return self._get('%s/links' % devid)
    
    def get_dev_archives(self, devid):
        # return json object with archive info
        # require device ID
        return self._get('%s/archives' % devid)
    
    def get_links(self):
        # return json object with all links
        return self._get('links')
    
    def get_link(self, lnkid):
        # return json object with link info
        # require link ID
        return self._get('links/%s' % lnkid)
    
    def get_link_custom(self, lnkid):
        # return json object with the custom attribute values of the link
        # require link ID
        return self._get('links/%s/custom-attribute-values' % lnkid)

    def get_alert_profiles(self):
        # return json object with all metric classes
        return self._get('alert-profiles')

    def get_alert_profiles_pandas(self):
        alerts = self.get_alert_profiles()
        if u'items' in alerts:
            for alert in alerts[u'items']:
                a.append([alert[u'id'], alert[u'displayName']])
        return pandas.DataFrame(a, columns=[u'id', u'displayName'])

    def get_alert_profile(self, profileId):
        # return json object with all metric classes
        return self._get('alert-profiles/%s' % profileId)

    def get_polling_profiles(self):
        # return json object with all metric classes
        return self._get('polling-profiles')

    def get_polling_profile(self, profileId):
        # return json object with all metric classes
        return self._get('polling-profiles/%s' % profileId)

    def get_metric_classes(self):
        # return json object with all metric classes
        return self._get('metric-classes')
    
    def get_metric_class(self, mtrid):
        # return json object with metric class
        # require metric ID
        return self._get('metric-classes/%s' % mtrid)
    
    def get_metric_data(self, **a):
        # Returns metric data for the given query
        # Requires key=value arguments passed to web function
        '''
	fargs = '?'
        for param, value in a.items():
            fargs += "%s=%s&" % (param, value)
        return self._get('metric-data%s' % fargs[:-1])
	'''
        if a:
                if a['params']:
                    	return self._get('metric-data', params=a['params'])
        else:
                return self._get('metric-data')

    def get_devices_in_group(self, groupId, **a):
        grpData = self.get_group_devices(groupId)
        if not self._validate_mget(grpData):
            return []
        devList = []
        for rec in grpData['items']:
            devList.append([rec[u'id'], rec[u'name']])
        return devList

    def _validate_mget(self, jsonData):
        if not u'items' in jsonData:
            logger.error('get_devices_all did not return any data')
            return False
        if not u'meta' in jsonData:
            logger.error('get_devices_all did not return any metadata')
            return False
        if not u'count' in jsonData[u'meta']:
            logger.error('get_devices_all did not return correct metadata')
            return False
        if int(jsonData[u'meta'][u'count']) < 1:
            logger.warning('get_devices_all returned 0 items')
            return False
        return True

    def _get(self, path, **a):
        # query NetIM
        #print('Params:')
        if a:
                if a['params']:
                        #print(a)
                        return self._req(u'GET', path, params=a['params'])
        else:
                #print('None')
                return self._req(u'GET', path)
    
    '''
    
    def query(self, query, **params):
        return self._req("POST", "Query",
                         {'query': query, 'parameters': params})

    def invoke(self, entity, verb, *args):
        return self._req("POST", "Invoke/%s/%s" % (entity, verb), args)

    def create(self, entity, **properties):
        return self._req("POST", "Create/" + entity, properties)

    def read(self, uri):
        return self._req("GET", uri)

    def update(self, uri, **properties):
        self._req("POST", uri, properties)

    def delete(self, uri):
        self._req("DELETE", uri)
   '''
 
    def _req(self, method, path, data=None, params=None):
        logger.debug('Request: %s' % self.base_url + path)
        print('Request: %s' % self.base_url + path)
        print('Params: ')
        print(params)
        total = 0
        count = -1
        next_offset = -1
        rdata = {u'items' : []}
        #reqargs = ''
        while (next_offset < total):
            #reqdat = self.conn.json_request(method,
            #                          self.base_url + path + reqargs,
            #                          body=json.dumps(data), params=params)
            reqdat = self.conn.json_request(method,
                                      self.base_url + path,
                                      body=json.dumps(data), params=params)
            if 'items' in reqdat:
                rdata[u'items'] += reqdat[u'items']
            else:
                return reqdat
            if 'meta' in reqdat:
                total = reqdat[u'meta'][u'total']
                count = reqdat[u'meta'][u'count']
                prev_offset = reqdat[u'meta'][u'prev_offset']
                next_offset = reqdat[u'meta'][u'next_offset']
                if next_offset == None:
                    return rdata
                logger.debug('\tRequest returned total: %s  count: %s  offset: %s' % (total, count, prev_offset))
                print('\tRequest returned total: %s  count: %s  prev_offset: %s  next_offset %s ' % (total, count, prev_offset, next_offset))
                if next_offset > 0 and next_offset < total:
                    if params:
                        params[u'offset'] = reqdat[u'meta'][u'next_offset']
                    else:
                        params = { u'offset' : reqdat[u'meta'][u'next_offset'] }
                    '''
                    if '?' in path:
                        reqargs = '&offset=%s' % reqdat['meta']['next_offset']
                    else:
                        reqargs = '?offset=%s' % reqdat['meta']['next_offset']
                    '''
        return rdata

