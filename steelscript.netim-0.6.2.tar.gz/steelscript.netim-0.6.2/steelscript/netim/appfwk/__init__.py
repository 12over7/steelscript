default_app_config = 'steelscript.netim.appfwk.plugin.SteelScriptAppConfig'
