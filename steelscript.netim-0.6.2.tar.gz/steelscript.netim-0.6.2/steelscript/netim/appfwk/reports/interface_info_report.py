# Copyright (c) 2018 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.

import steelscript.appfwk.apps.datasource.modules.analysis as analysis
from steelscript.appfwk.apps.report.models import Report
from steelscript.appfwk.apps.datasource.models import Column, TableField
import steelscript.appfwk.apps.report.modules.c3 as c3
import steelscript.appfwk.apps.report.modules.tables as tables

# Import the datasource module for this plugin
import steelscript.netim.appfwk.datasources.interface as netim

report = Report.create("Interface Properties", position=14)

report.add_section()

table = netim.getIfInfoTable.create(name='Interface Info')
table.add_column('id', 'ID', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('device', 'Device', datatype=Column.DATATYPE_STRING)
table.add_column('ifPreferredName', 'Name', datatype=Column.DATATYPE_STRING)
table.add_column('ifIndex', 'Interface Index', datatype=Column.DATATYPE_INTEGER)
table.add_column('ifAdminStatus', 'Admin Status', datatype=Column.DATATYPE_STRING)
table.add_column('ifOperStatus', 'Operational Status', datatype=Column.DATATYPE_STRING)
table.add_column('ipAddr', 'IP', datatype=Column.DATATYPE_STRING)
table.add_column('ifPhysAddress', 'MAC', datatype=Column.DATATYPE_STRING)
table.add_column('ifType','Interface Type', datatype=Column.DATATYPE_STRING)

report.add_widget(tables.TableWidget, table, "Interface Details", width=12)

#
# Define a criteria table that just displays all criteria for a
# given report run
#
table = analysis.CriteriaTable.create('ldap-criteria')
report.add_widget(tables.TableWidget, table, "Report Criteria",
                  width=12, height=200)


