# Copyright (c) 2018 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.

import steelscript.appfwk.apps.datasource.modules.analysis as analysis
from steelscript.appfwk.apps.report.models import Report
from steelscript.appfwk.apps.datasource.models import Column, TableField
import steelscript.appfwk.apps.report.modules.tables as tables

# Import the datasource module for this plugin
import steelscript.netim.appfwk.datasources.flow as netim

report = Report.create("Enriched NetProfiler Traffic Flow Report", position=14)

report.add_section()

table = netim.tflTable.create(name='Traffic Flow Report')
table.add_column('cli_host_ip', 'Client IP', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('cli_host_dns', 'Client', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('cli_topo', 'Client Interface', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('cli_topo_dns', 'Topology (cli -> srv)', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('srv_host_ip', 'Server IP', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('srv_host_dns', 'Server', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('protocol_name', 'Protocol', datatype=Column.DATATYPE_STRING, iskey=True)
table.add_column('srv_port', 'Server Port', datatype=Column.DATATYPE_STRING, iskey=True)

table.add_column('c2s_total_bytes', 'Total Bytes (cli -> srv)', datatype=Column.DATATYPE_STRING)
table.add_column('c2s_total_pkts', 'Total Packets (cli -> srv)', datatype=Column.DATATYPE_STRING)
table.add_column('s2c_total_bytes', 'Total Bytes (srv -> cli)', datatype=Column.DATATYPE_STRING)
table.add_column('s2c_total_pkts', 'Total Packets (srv -> cli)', datatype=Column.DATATYPE_STRING)

report.add_widget(tables.TableWidget, table, "Traffic Flow Report", width=12)

#
# Define a criteria table that just displays all criteria for a
# given report run
#
table = analysis.CriteriaTable.create('flow-criteria')
report.add_widget(tables.TableWidget, table, "Flow Criteria",
                  width=12, height=200)



