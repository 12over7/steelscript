# Copyright (c) 2019 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.


import logging
import pandas
import threading

from steelscript.common.timeutils import \
    datetime_to_seconds, timedelta_total_seconds, parse_timedelta, \
    TimeParser, ensure_timezone
from steelscript.appfwk.apps.jobs import \
    QueryComplete
from steelscript.appfwk.apps.datasource.models import \
    DatasourceTable, Column, TableField
from steelscript.appfwk.apps.devices.forms import fields_add_device_selection
from steelscript.appfwk.apps.devices.devicemanager import DeviceManager
from steelscript.netprofiler.core.report import \
    Report, SingleQueryReport, TrafficTimeSeriesReport, TrafficFlowListReport
from steelscript.netprofiler.core.filters import TimeFilter, TrafficFilter
from steelscript.appfwk.apps.datasource.forms import \
    fields_add_time_selection, fields_add_resolution
from steelscript.netprofiler.appfwk.datasources.netprofiler import NetProfilerQuery

from steelscript.netim.core.netim import *

logger = logging.getLogger(__name__)
lock = threading.Lock()

APP_LABEL = 'steelscript.netim.appfwk'

tfl_cols = [
    'cli_host_ip',
    'cli_host_dns',
    'cli_topo',
    'cli_topo_dns',
    'srv_host_ip',
    'srv_host_dns',
    'protocol_name',
    'srv_port',
    'start_time',
    'end_time',
    'duration',
    'c2s_total_bytes',
    'c2s_total_pkts',
    's2c_total_bytes',
    's2c_total_pkts'
    ]


#
# Define a custom Column class
#
# This allows defintion of custom column options that may
# be set in reports.
#
# Use of this class is entirely optional, it may be deleted
# if there are no custom column options

class tflColumn(Column):
    class Meta:
        proxy = True
        app_label = APP_LABEL

    # COLUMN_OPTIONS is a dictionary of options that
    # are specific to columns for tables in this file.
    # the column options are available when the query is run.
    # The values are stored with the column definition at
    # table / column defintiion time.

    COLUMN_OPTIONS = { }


#
# Define a base interfaceTable
#
class tflTable(DatasourceTable):

    class Meta:
        proxy = True
        app_label = APP_LABEL

    # When a custom column is used, it must be linked
    _column_class = 'tflColumn'

    # Name of the query class to extract data
    _query_class = 'tflQuery'

    # TABLE_OPTIONS is a dictionary of options that are
    # specific to tflQuery objects.  These will be overriden by
    # keyword arguments to the tflTable.create() call in a report
    # file
    TABLE_OPTIONS = {
                     'groupby': 'hpr',
                     'realm': 'traffic_flow_list',
                     'interface': None,
                     'centricity': 'hos',
                     'template_id': 184
                     }
    
    # default field parameters
    FIELD_OPTIONS = {'duration': 60,
                     'durations': ('15 min', '1 hour',
                                   '2 hours', '4 hours', '12 hours',
                                   '1 day', '1 week', '4 weeks'),
                     'resolution': 'auto',
                     'resolutions': (('auto', 'Automatic'),
                                     '1min', '15min', 'hour', '6hour'),
                     }
    
    def post_process_table(self, field_options):
        resolution = field_options['resolution']
        if resolution != 'auto':
            if isinstance(resolution, int):
                res = resolution
            else:
                res = int(timedelta_total_seconds(parse_timedelta(resolution)))
            resolution = Report.RESOLUTION_MAP[res]
            field_options['resolution'] = resolution

        fields_add_device_selection(self, keyword='netim_device',
                label='NetIM', module='netim_device', enabled=True)
        
        fields_add_device_selection(self, keyword='netprofiler_device',
                                    label='NetProfiler', module='netprofiler',
                                    enabled=True)
        
        duration = field_options['duration']
        if isinstance(duration, int):
            duration = "%d min" % duration

        fields_add_time_selection(self,
                                  initial_duration=duration,
                                  durations=field_options['durations'])

        fields_add_resolution(self,
                              initial=field_options['resolution'],
                              resolutions=field_options['resolutions'],
                              special_values=['auto'])
        self.fields_add_filterexpr()

    def fields_add_filterexpr(self, keyword='netprofiler_filterexpr',
                              initial='hostgroup ByLocation:zone_0'):
        field = TableField(keyword=keyword,
                           label='NetProfiler Filter Expression',
                           help_text=('Traffic expression using NetProfiler '
                                      'Advanced Traffic Expression syntax'),
                           initial=initial,
                           required=False)
        field.save()
        self.fields.add(field)

    def fields_add_filterexprs_field(self, keyword):

        field = self.fields.get(keyword='netprofiler_filterexpr')
        field.post_process_func = Function(
            function=_post_process_combine_filterexprs
        )

        parent_keywords = set(field.parent_keywords or [])
        parent_keywords.add(keyword)
        field.parent_keywords = list(parent_keywords)
        field.save()

        return field

    @classmethod
    def extend_filterexpr(cls, obj, keyword, template):

        field = obj.fields.get(keyword='netprofiler_filterexpr')
        field.post_process_func = Function(
            function=_post_process_combine_filterexprs
        )

        TableField.create(
            keyword=keyword, obj=obj, hidden=True,
            post_process_template=template)

        parent_keywords = set(field.parent_keywords or [])
        parent_keywords.add(keyword)
        field.parent_keywords = list(parent_keywords)
        field.save()

    def fields_add_query_args(self, help_text, keyword='api_query_args',
                                initial=None, **kwargs):
        field = TableField(keyword=keyword,
                           label='Query Parameters',
                           help_text=(help_text),
                           initial=initial,
                           required=False)
        field.save()
        self.fields.add(field)



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# Functions for pulling back device attributes from NetIM
#
# flow_src = { device_ip : [ device_name, device_id, {ifIndex : ifName, ifIndex : ifName} ] }
DNAME = 0
DEVID = 1
IFDICT = 2
flow_src = { }
# JSON returned from "/v1/devices" query
NETIM_DEVICES = { }

def get_devices_info(n):
    # retrieve all devices from NetIM
    logger.info("Fetching device info from NetIM %s" % n.host)
    NETIM_DEVICES = n.get_devices()
    if not u'items' in NETIM_DEVICES:
        logger.debug("Unable to fetch NetIM device records")
        return False
    for dev in NETIM_DEVICES[u'items']:
        if u'primaryAddress' in dev:
            flow_src[dev[u'primaryAddress']] = [ dev[u'deviceName'], dev[u'id'], { } ] 
        if u'accessAddress' in dev:
            flow_src[dev[u'accessAddress']] = [ dev[u'deviceName'], dev[u'id'], { } ] 
    return True


def get_dev_interface_info(n, device_ip, ifIdx):
    # retrieve interface data for a given NetIM device and ifIndex
    if not device_ip in flow_src:
        logger.debug("Function get_device_interfaces_info called when no device_ip in flow_src dict")
        return False
    logger.info("Fetching interface info from NetIM %s for device id# %s" % (n.host, flow_src[device_ip][DEVID]))
    data = n.get_interfaces(deviceIp=device_ip, ifIndex=ifIdx)
    if not u'items' in data:
        logger.debug("Unable to fetch NetIM interface record for %s ifIndex %s" (device_ip, ifIdx))
        return False
    elif data[u'items'].__len__() != 1:
        logger.debug("NetIM interface record returned wrong number of items: %s" % data[u'items'].__len__() )
        return False
    else:
        flow_src[device_ip][IFDICT][ifIdx] = data[u'items'][0][u'ifPreferredName']
    return data[u'items'][0][u'ifPreferredName']


def get_device_interfaces_info(n, device_ip):
    # retrieve all interfaces for a given NetIM device
    if not device_ip in flow_src:
        logger.debug("Function get_device_interfaces_info called when no device_ip in flow_src dict")
        return False
    logger.info("Fetching interface info from NetIM %s for device id# %s" % (n.host, flow_src[device_ip][DEVID]))
    data = n.get_dev_interfaces(flow_src[device_ip][DEVID])
    if not u'items' in data:
        logger.debug("Unable to fetch NetIM device records")
        return False
    for itfc in data[u'items']:
        flow_src[device_ip][IFDICT][itfc[u'ifIndex']] = itfc[u'ifPreferredName']
    return True


def get_device_name(n, device_ip):
    if flow_src.__len__() == 0:
        get_devices_info(n)
    if device_ip in flow_src:
        return flow_src[device_ip][0]
    elif flow_src.__len__() > 0:
        logger.debug("Unable to fetch NetIM device record for device IP %s" % device_ip)
    return device_ip


def get_interface_name(n, device_ip, ifIdx):
    if device_ip in flow_src:
        if ifIdx in flow_src[device_ip][IFDICT]:
            return flow_src[device_ip][IFDICT][ifIdx]
        else:
            ifname = get_dev_interface_info(n, device_ip, ifIdx)
        if ifname:
            return ifname
    return str(ifIdx)


def clean_dns(dns_string):
    parts = dns_string.split('|')
    if parts.__len__() != 2:
        return dns_string
    if parts[1].__len__() > 1:
        return parts[1]
    return parts[0]


def pretty_topo(topo_string):
    parts = topo_string.split('|')
    hops = []
    for x in xrange(0, parts.__len__(), 6):
        if x+6 > parts.__len__():
            break
        hn = x+1
        intf = x+2
        if parts[hn].__len__() < 7:
            continue
        hops.append("%s : %s" % (parts[hn],parts[intf]))
    return ' -> '.join(hops)


def enrich_topo(n, topo_string):
    #example: topo_string = '192.168.1.1|192.168.1.1|6|||0|192.168.2.1|192.168.2.1|11|||0|NA|NA||'
    #return: topo_string = 'router1|192.168.1.1|eth0|||0|router2|192.168.2.1|fe-0/0/1|||0|NA|NA||'
    #logger.debug("Enriching topology string: %s" % topo_string)
    parts = topo_string.split('|')
    for x in xrange(0, parts.__len__(), 6):
        if x+6 > parts.__len__():
            break
        ip = x
        hn = x+1
        ifid = x+2
        dscp = x+5
        if parts[ip].__len__() < 7:
            #logger.debug("ip field in topo is < 7: %s  x:%s" % (parts[ip], str(x)))
            continue
        if parts[hn] == parts[ip]:
            if parts[ip] in flow_src:
                parts[hn] = flow_src[parts[ip]][DNAME]
                #logger.debug("found device ip in flow_src %s  %s" % (parts[ip], parts[hn]))
                if parts[ifid] in flow_src[parts[ip]][IFDICT]:
                    parts[ifid] = flow_src[parts[ip]][IFDICT][parts[ifid]]
                else:
                    #logger.debug("calling get_interface_name(%s, %s)" % (parts[ip], parts[ifid]))
                    parts[ifid] = get_interface_name(n, parts[ip], parts[ifid])
            else:
                #logger.debug("calling get_device_name(%s, %s)" % (n.host, parts[ip]))
                parts[hn] = get_device_name(n, parts[ip])
                #logger.debug("calling get_interface_name(%s, %s)" % (parts[ip], parts[ifid]))
                parts[ifid] = get_interface_name(n, parts[ip], parts[ifid])
    #logger.debug("Enriched topology string: %s" % '|'.join(parts))
    return pretty_topo( '|'.join(parts) )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




#
# The tflQuery class must be defined with the __init__ and run
# method taking the defined arguments
#
class tflQuery(NetProfilerQuery):

    def _prepare_report_args(self):
        class Args(object):
            pass
        args = Args()

        criteria = self.job.criteria

        if criteria.netprofiler_device == '':
            logger.debug('%s: No netprofiler device selected' % self.table)
            self.job.mark_error("No NetProfiler Device Selected")
            return False

        args.profiler = DeviceManager.get_device(criteria.netprofiler_device)
        
        args.columns = tfl_cols
        
        args.sortcol = None
        if self.table.sortcols is not None:
            args.sortcol = self.table.sortcols[0]

        args.timefilter = TimeFilter(start=criteria.starttime,
                                     end=criteria.endtime)

        logger.info("Running NetProfiler table %d report for timeframe %s" %
                    (self.table.id, str(args.timefilter)))

        if ('datafilter' in criteria) and (criteria.datafilter is not None):
            args.datafilter = criteria.datafilter.split(',')
        else:
            args.datafilter = None

        args.trafficexpr = TrafficFilter(
            self.job.combine_filterexprs(exprs=criteria.netprofiler_filterexpr)
        )

        # Incoming criteria.resolution is a timedelta
        logger.debug('NetProfiler report got criteria resolution %s (%s)' %
                     (criteria.resolution, type(criteria.resolution)))
        if criteria.resolution != 'auto':
            rsecs = int(timedelta_total_seconds(criteria.resolution))
            args.resolution = Report.RESOLUTION_MAP[rsecs]
        else:
            args.resolution = 'auto'

        logger.debug('NetProfiler report using resolution %s (%s)' %
                     (args.resolution, type(args.resolution)))

        args.limit = (self.table.options.limit
                      if hasattr(self.table.options, 'limit') else None)

        args.templateid = (self.table.options.templateid
                      if hasattr(self.table.options, 'templateid') else None)

        if getattr(self.table.options, 'interface', False):
            args.centricity = 'int'
        else:
            args.centricity = 'hos'

        return args

    def run(self):
        criteria = self.job.criteria
        
        if criteria.netim_device == '':
            logger.debug('%s: No netim_device selected' % self.table)
            self.job.mark_error("No netim_device selected")
            return False
        
        # get profiler report args
        args = self._prepare_report_args()

        logger.debug('Report args: %s %s %s' % (str(args.columns), args.trafficexpr, args.limit))

        with lock:
            report = TrafficFlowListReport(args.profiler)
            report.run(args.columns,
                       sort_col=args.sortcol,
                       timefilter=args.timefilter,
                       trafficexpr=args.trafficexpr,
                       limit=args.limit
                       )

        data = self._wait_for_data(report)
        headers = report.get_legend()

        if data:
            #cols =[col.name for col in self.table.get_columns(synthetic=False)]
            cols = args.columns
            logger.info("Report has %s columns" % str(cols) )
            logger.info("Report %s returned %s rows" % (self.job, data.__len__()))
        else:
            cols = None
            logger.info("Report %s returned no data" % (self.job))
            self.job.mark_error("Report %s returned no data" % (self.job))
        
        # calls the NetIM class
        n = DeviceManager.get_device(criteria.netim_device)
        
        # get column labels
        #legend = [clm.label for clm in rpt.get_legend()]
        
        cli_dns_field = srv_dns_field = cli_topo_dns_field = srv_topo_dns_field = -1        
        for x in xrange( tfl_cols.__len__() ):
            if tfl_cols[x] == 'cli_host_dns':
                cli_dns_field = x
            elif tfl_cols[x] == 'srv_host_dns':
                srv_dns_field = x
            elif tfl_cols[x] == 'cli_topo_dns':
                cli_topo_dns_field = x
            elif tfl_cols[x] == 'srv_topo_dns':
                srv_topo_dns_field = x
        for row in data:
            if cli_topo_dns_field >= 0:
                row[cli_topo_dns_field] = enrich_topo(n, row[cli_topo_dns_field])
            if srv_topo_dns_field >= 0:
                row[srv_topo_dns_field] = enrich_topo(n, row[srv_topo_dns_field])
            if cli_dns_field >= 0:
                row[cli_dns_field] = clean_dns( row[cli_dns_field] )
            if srv_dns_field >= 0:
                row[srv_dns_field] = clean_dns( row[srv_dns_field] )
        
        
        # Convert to a pandas dataframe to ensure we have the right labels
        df = pandas.DataFrame(data, columns=cols)
        
        logger.info("Report %s returned %s rows" % (self.job, len(df)))
        return QueryComplete(df)





