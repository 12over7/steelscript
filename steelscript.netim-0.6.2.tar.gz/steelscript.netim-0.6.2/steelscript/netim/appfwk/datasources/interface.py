# Copyright (c) 2019 Riverbed Technology, Inc.
#
# This software is licensed under the terms and conditions of the MIT License
# accompanying the software ("License").  This software is distributed "AS IS"
# as set forth in the License.

"""
This file defines a data source for querying data.

There are three parts to defining a data source:

* Defining column options via a Column class
* Defining table options via a DatasourceTable
* Defining the query mechanism via a Query class

Note that you can define multiple Column and Table classes
in the same file. Each Table class needs to associate with a
Query class by specifying the _query_class attribute.

"""

import logging
import pandas
from pprint import pprint

from steelscript.common.timeutils import \
    datetime_to_seconds, timedelta_total_seconds, parse_timedelta, \
    TimeParser, ensure_timezone
from steelscript.appfwk.apps.jobs import \
    QueryComplete
from steelscript.appfwk.apps.datasource.models import \
    DatasourceTable, TableQueryBase, Column, TableField
from steelscript.appfwk.apps.datasource.modules.analysis import \
    AnalysisTable, AnalysisQuery
from steelscript.appfwk.apps.devices.forms import fields_add_device_selection
from steelscript.appfwk.apps.devices.devicemanager import DeviceManager
from steelscript.appfwk.apps.datasource.forms import \
    fields_add_time_selection, fields_add_resolution

#from steelscript.common.service import Auth, UserAuth
from steelscript.netim.core.netim import *

logger = logging.getLogger(__name__)

ifStatus = { 1:'Up', 2:'Down', 3:'Test' }
APP_LABEL = 'steelscript.netim.appfwk'

#
# Define a custom Column class
#
# This allows defintion of custom column options that may
# be set in reports.
#
# Use of this class is entirely optional, it may be deleted
# if there are no custom column options

class interfaceColumn(Column):
    class Meta:
        proxy = True
        app_label = 'steelscript.netim.appfwk'

    # COLUMN_OPTIONS is a dictionary of options that
    # are specific to columns for tables in this file.
    # the column options are available when the query is run.
    # The values are stored with the column definition at
    # table / column defintiion time.

    COLUMN_OPTIONS = { }


#
# Define a base interfaceTable
#
class interfaceTable(DatasourceTable):

    class Meta:
        proxy = True
        app_label = 'steelscript.netim.appfwk'

    # When a custom column is used, it must be linked
    _column_class = 'interfaceColumn'

    # Name of the query class to extract data
    _query_class = 'interfaceQuery'

    # TABLE_OPTIONS is a dictionary of options that are
    # specific to interfaceQuery objects.  These will be overriden by
    # keyword arguments to the interfaceTable.create() call in a report
    # file
    TABLE_OPTIONS = { }

    # FIELD_OPTIONS is a dictionary of default values for field
    # options.  These by be overriden by keyword arguments to the
    # interfaceTable.create() call in a report file
    FIELD_OPTIONS = {'polledOnly': 'false',
                     'polledOnlyOpts': ('true', 'false')
                     }
    
    def post_process_table(self, field_options):
        #
        # Add criteria fields that are required by this table
        #
        #pass
        fields_add_device_selection(self, keyword='netim_device',
                label='NetIM', module='netim_device', enabled=True)

    def fields_add_query_args(self, help_text, keyword='api_query_args',
                                initial=None, **kwargs):
        field = TableField(keyword=keyword,
                           label='Query Parameters',
                           help_text=(help_text),
                           initial=initial,
                           required=False)
        field.save()
        self.fields.add(field)


class getIfInfoTable(interfaceTable):
    
    class Meta:
        proxy = True
        app_label = APP_LABEL
    
    TABLE_OPTIONS = {'api_query_args': None}


    def post_process_table(self, field_options):
        super(getIfInfoTable, self).post_process_table(field_options)
        
        # Add parameter field to query criteria
        self.fields_add_query_args('Parameters separated by commas', initial='polledOnly=true', required=True)
    
def parse_parameters(param_string):
    if param_string == '':
        return {}
    return dict(x.split('=') for x in param_string.split(','))
    

#
# The interfaceQuery class must be defined with the __init__ and run
# method taking the defined arguments
#
class interfaceQuery(TableQueryBase):

    def run(self):
        # This method is called to actually execute the query
        # for the given table and job.  This is executed in a separate
        # thread and must not return until either the query completes
        # and data is available, or the query fails and returns an error.
        #
        # On success, this function should return either a list of lists
        # of data aligned to the set of non-synthetic columns associated
        # with this table or a pandas DataFrame with matching columns.
        # (synthetic columns are computed by automatically one the query
        # completes)
        #
        # On error, any errors that are not programmatic (like bad
        # criteria values) should be reported by calling
        # self.job.mark_error() with a user-friendly error message
        # indicating the cause of the failure.
        #
        # Any programmatic errors should be raised as exceptions.
        #
        # For long running queries self.job.mark_progress() should
        # be called to update the progress from 0 to 100 percent complete.

        # All user entered criteria is available directly from this object.
        # Values for any fields added to the table will appear as
        # attributes according to the field keyword.
        criteria = self.job.criteria

        # check that a netim device was selected
        if criteria.netim_device == '':
            logger.debug('%s: No netim_device selected' % self.table)
            self.job.mark_error("No netim_device selected")
            return False
        
        # calls the NetIM class
        n = DeviceManager.get_device(criteria.netim_device)
        
        logger.debug("Creating columns for NetIM table %d" % self.table.id)
        
        # Report Criteria "Query Parameters" are passed to this function
        # as keyword args.  They should be in the form:
        #   deviceIp=192.168.1.1,polledOnly=true
        #   ifIndex=12345
        #   interfaceIp=10.10.10.1
        paramargs = parse_parameters(criteria.api_query_args)
        i = n.get_interfaces(**paramargs)
        logger.debug('Query returned %s records.' % str(len(i[u'items'])))
        
        col = set()
        
        for intfc in i[u'items']:
            for param, value in intfc.iteritems():
                col.add(param)
        logger.debug('Set object has %s elements' % str( col.__len__() ))
        if u'meta' in col:
            col.remove(u'meta')
        else:
            logger.debug('No data returned from query')
            self.job.mark_error("No data returned from query")
        if u'containers' in col:
            col.remove(u'containers')
        else:
            logger.debug('No data returned from query')
            self.job.mark_error("No data returned from query")
        col.add(u'device')
        logger.debug('Set object has %s elements after add/remove.' % str( col.__len__() ))
        cols = list(col)
        logger.debug('List object has %s elements' % str( cols.__len__() ))
        logger.debug('Query of %s returned the following columns:  %s' % (n.host, pprint(cols)))
        
        data = []
        
        for intfc in i[u'items']:
            rec = []
            dev = intfc[u'containers'][u'device'][u'name']
            logger.debug('Iterating %s interface %s' % (dev,intfc[u'name']))
            for c in cols:
                logger.debug('Table column: %s' % c )
                if c in intfc:
                    if c in (u'ifAdminStatus', u'ifOperStatus'):
                        logger.debug('Translating integer status %s to %s' % (str(intfc[c]),ifStatus[intfc[c]]) )
                        rec.append(ifStatus[intfc[c]])
                    else:
                        rec.append(intfc[c])
                elif c == u'device':
                    rec.append(dev)
                else:
                    rec.append('')
            #logger.debug('Table data for %s has %s records:  %s' % (dev, str(rec.__len__()), str(rec)))
            data.append(rec)
            
        logger.debug('Table data has %s records:  %s' % (str(data.__len__()), str(data)))
        # Convert to a pandas dataframe to ensure we have the right labels
        if data:
            df = pandas.DataFrame(data, columns=cols)
            logger.info("Report %s returned %s rows" % (self.job, len(df)))
        else:
            df = None
            logger.info("Report %s returned no data" % (self.job))

        # If all went well, return a ``QueryComplete`` object.
        return QueryComplete(df)



