netim
========
Interface to Riverbed NetIM

The directory structure is as follows:

* ./README.rst -- this file
* ./setup.py -- package installation parameters
* ./steelscript -- package source files files
* ./steelscript/netim/core/ -- core source files
* ./steelscript/netim/appfwk/plugin.py -- plugin information
* ./steelscript/netim/appfwk/datasources/ - directory
* ./steelscript/netim/appfwk/devices/ - directory of devices
* ./steelscript/netim/appfwk/reports/ - directory of reports
* ./steelscript/netim/appfwk/libs/ - helper functions
